#!/bin/bash
echo $((RANDOM % 100)) > test1-primo.in
